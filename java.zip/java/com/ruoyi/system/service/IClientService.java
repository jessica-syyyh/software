package com.ruoyi.system.service;

import java.util.List;
import com.ruoyi.system.domain.Client;

/**
 * 会员Service接口
 * 
 * @author ruoyi
 * @date 2021-01-02
 */
public interface IClientService 
{
    /**
     * 查询会员
     * 
     * @param clientName 会员ID
     * @return 会员
     */
    public Client selectClientById(String clientName);

    /**
     * 查询会员列表
     * 
     * @param client 会员
     * @return 会员集合
     */
    public List<Client> selectClientList(Client client);

    /**
     * 新增会员
     * 
     * @param client 会员
     * @return 结果
     */
    public int insertClient(Client client);

    /**
     * 修改会员
     * 
     * @param client 会员
     * @return 结果
     */
    public int updateClient(Client client);

    /**
     * 批量删除会员
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    public int deleteClientByIds(String ids);

    /**
     * 删除会员信息
     * 
     * @param clientName 会员ID
     * @return 结果
     */
    public int deleteClientById(String clientName);
}
