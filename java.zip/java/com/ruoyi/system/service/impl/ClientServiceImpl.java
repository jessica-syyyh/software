package com.ruoyi.system.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.system.mapper.ClientMapper;
import com.ruoyi.system.domain.Client;
import com.ruoyi.system.service.IClientService;
import com.ruoyi.common.core.text.Convert;

/**
 * 会员Service业务层处理
 * 
 * @author ruoyi
 * @date 2021-01-02
 */
@Service
public class ClientServiceImpl implements IClientService 
{
    @Autowired
    private ClientMapper clientMapper;

    /**
     * 查询会员
     * 
     * @param clientName 会员ID
     * @return 会员
     */
    @Override
    public Client selectClientById(String clientName)
    {
        return clientMapper.selectClientById(clientName);
    }

    /**
     * 查询会员列表
     * 
     * @param client 会员
     * @return 会员
     */
    @Override
    public List<Client> selectClientList(Client client)
    {
        return clientMapper.selectClientList(client);
    }

    /**
     * 新增会员
     * 
     * @param client 会员
     * @return 结果
     */
    @Override
    public int insertClient(Client client)
    {
        return clientMapper.insertClient(client);
    }

    /**
     * 修改会员
     * 
     * @param client 会员
     * @return 结果
     */
    @Override
    public int updateClient(Client client)
    {
        return clientMapper.updateClient(client);
    }

    /**
     * 删除会员对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    @Override
    public int deleteClientByIds(String ids)
    {
        return clientMapper.deleteClientByIds(Convert.toStrArray(ids));
    }

    /**
     * 删除会员信息
     * 
     * @param clientName 会员ID
     * @return 结果
     */
    @Override
    public int deleteClientById(String clientName)
    {
        return clientMapper.deleteClientById(clientName);
    }
}
