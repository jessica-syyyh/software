package com.ruoyi.system.domain;

import java.math.BigDecimal;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.core.domain.BaseEntity;

/**
 * 商品管理对象 xin_pro
 * 
 * @author qw
 * @date 2021-01-07
 */
public class XinPro extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /**  */
    private Long proId;

    /**  */
    @Excel(name = "")
    private String proName;

    /**  */
    @Excel(name = "")
    private BigDecimal proPrice;

    /**  */
    @Excel(name = "")
    private String proType;

    /**  */
    @Excel(name = "")
    private String proText;

    public void setProId(Long proId) 
    {
        this.proId = proId;
    }

    public Long getProId() 
    {
        return proId;
    }
    public void setProName(String proName) 
    {
        this.proName = proName;
    }

    public String getProName() 
    {
        return proName;
    }
    public void setProPrice(BigDecimal proPrice) 
    {
        this.proPrice = proPrice;
    }

    public BigDecimal getProPrice() 
    {
        return proPrice;
    }
    public void setProType(String proType) 
    {
        this.proType = proType;
    }

    public String getProType() 
    {
        return proType;
    }
    public void setProText(String proText) 
    {
        this.proText = proText;
    }

    public String getProText() 
    {
        return proText;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("proId", getProId())
            .append("proName", getProName())
            .append("proPrice", getProPrice())
            .append("proType", getProType())
            .append("proText", getProText())
            .toString();
    }
}
