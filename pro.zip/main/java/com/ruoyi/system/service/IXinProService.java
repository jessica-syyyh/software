package com.ruoyi.system.service;

import java.util.List;
import com.ruoyi.system.domain.XinPro;

/**
 * 商品管理Service接口
 * 
 * @author qw
 * @date 2021-01-07
 */
public interface IXinProService 
{
    /**
     * 查询商品管理
     * 
     * @param proId 商品管理ID
     * @return 商品管理
     */
    public XinPro selectXinProById(Long proId);

    /**
     * 查询商品管理列表
     * 
     * @param xinPro 商品管理
     * @return 商品管理集合
     */
    public List<XinPro> selectXinProList(XinPro xinPro);

    /**
     * 新增商品管理
     * 
     * @param xinPro 商品管理
     * @return 结果
     */
    public int insertXinPro(XinPro xinPro);

    /**
     * 修改商品管理
     * 
     * @param xinPro 商品管理
     * @return 结果
     */
    public int updateXinPro(XinPro xinPro);

    /**
     * 批量删除商品管理
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    public int deleteXinProByIds(String ids);

    /**
     * 删除商品管理信息
     * 
     * @param proId 商品管理ID
     * @return 结果
     */
    public int deleteXinProById(Long proId);
}
