package com.ruoyi.system.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.system.mapper.XinProMapper;
import com.ruoyi.system.domain.XinPro;
import com.ruoyi.system.service.IXinProService;
import com.ruoyi.common.core.text.Convert;

/**
 * 商品管理Service业务层处理
 * 
 * @author qw
 * @date 2021-01-07
 */
@Service
public class XinProServiceImpl implements IXinProService 
{
    @Autowired
    private XinProMapper xinProMapper;

    /**
     * 查询商品管理
     * 
     * @param proId 商品管理ID
     * @return 商品管理
     */
    @Override
    public XinPro selectXinProById(Long proId)
    {
        return xinProMapper.selectXinProById(proId);
    }

    /**
     * 查询商品管理列表
     * 
     * @param xinPro 商品管理
     * @return 商品管理
     */
    @Override
    public List<XinPro> selectXinProList(XinPro xinPro)
    {
        return xinProMapper.selectXinProList(xinPro);
    }

    /**
     * 新增商品管理
     * 
     * @param xinPro 商品管理
     * @return 结果
     */
    @Override
    public int insertXinPro(XinPro xinPro)
    {
        return xinProMapper.insertXinPro(xinPro);
    }

    /**
     * 修改商品管理
     * 
     * @param xinPro 商品管理
     * @return 结果
     */
    @Override
    public int updateXinPro(XinPro xinPro)
    {
        return xinProMapper.updateXinPro(xinPro);
    }

    /**
     * 删除商品管理对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    @Override
    public int deleteXinProByIds(String ids)
    {
        return xinProMapper.deleteXinProByIds(Convert.toStrArray(ids));
    }

    /**
     * 删除商品管理信息
     * 
     * @param proId 商品管理ID
     * @return 结果
     */
    @Override
    public int deleteXinProById(Long proId)
    {
        return xinProMapper.deleteXinProById(proId);
    }
}
