package com.ruoyi.system.service;

import java.util.List;
import com.ruoyi.system.domain.SysDept;

/**
 * 职级管理Service接口
 * 
 * @author ruoyi
 * @date 2021-01-07
 */
public interface ISysDeptService 
{
    /**
     * 查询职级管理
     * 
     * @param deptId 职级管理ID
     * @return 职级管理
     */
    public SysDept selectSysDeptById(Long deptId);

    /**
     * 查询职级管理列表
     * 
     * @param sysDept 职级管理
     * @return 职级管理集合
     */
    public List<SysDept> selectSysDeptList(SysDept sysDept);

    /**
     * 新增职级管理
     * 
     * @param sysDept 职级管理
     * @return 结果
     */
    public int insertSysDept(SysDept sysDept);

    /**
     * 修改职级管理
     * 
     * @param sysDept 职级管理
     * @return 结果
     */
    public int updateSysDept(SysDept sysDept);

    /**
     * 批量删除职级管理
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    public int deleteSysDeptByIds(String ids);

    /**
     * 删除职级管理信息
     * 
     * @param deptId 职级管理ID
     * @return 结果
     */
    public int deleteSysDeptById(Long deptId);
}
